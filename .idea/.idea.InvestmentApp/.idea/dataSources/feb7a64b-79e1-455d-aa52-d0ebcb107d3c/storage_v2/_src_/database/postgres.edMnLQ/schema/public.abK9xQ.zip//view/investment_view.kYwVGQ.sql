create view investment_view (client_name, stock_rating, additional_stock_info, purchase_date, sale_date) as
SELECT client.name           AS client_name,
       stock.rating          AS stock_rating,
       stock.additional_info AS additional_stock_info,
       investment.purchase_date,
       investment.sale_date
FROM investment
         JOIN clients client ON client.id = investment.client_id
         JOIN stocks stock ON investment.stock_id = stock.id;

comment on view investment_view is 'Представление инвестиций';

alter table investment_view
    owner to postgres;

