create procedure clean_quotes_history()
    language plpgsql
as
$$
begin
    CREATE TEMPORARY TABLE tmp_investment_ids AS
    SELECT investment_id as tinvestment_id, max(date) as tdate
    FROM quotes_history GROUP BY investment_id;

    TRUNCATE TABLE quotes_history RESTART IDENTITY;

    INSERT INTO quotes_history (investment_id, date) SELECT tinvestment_id, tdate FROM tmp_investment_ids;

end;
$$;

alter procedure clean_quotes_history() owner to postgres;

