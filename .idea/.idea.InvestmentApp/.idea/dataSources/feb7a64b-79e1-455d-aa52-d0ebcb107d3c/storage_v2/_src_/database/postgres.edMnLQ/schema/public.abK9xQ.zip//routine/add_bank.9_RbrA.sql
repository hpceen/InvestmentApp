create procedure add_bank(IN bank_name text, IN bank_percent double precision)
    language plpgsql
as
$$
begin
    INSERT INTO banks (name, percent) VALUES (bank_name, bank_percent);
end;
$$;

alter procedure add_bank(text, double precision) owner to postgres;

