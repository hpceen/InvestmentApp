create function get_earned_amount(deposit_id integer) returns double precision
    language plpgsql
as
$$
declare
    deposit_amount double precision;
    deposit_percent double precision;
    earned_amount double precision := 0.0;
begin
    select percent into deposit_percent from banks where id = (select bank_id from deposits where id = deposit_id);
    select amount into deposit_amount from deposits where id = deposit_id;
    
    for i in 1..(SELECT deposit_duration from deposits where id = deposit_id)
    loop
        earned_amount := deposit_amount * (deposit_percent / 100);
        deposit_amount := deposit_amount + earned_amount;
    end loop;
    
    return deposit_amount;
end;
$$;

alter function get_earned_amount(integer) owner to postgres;

