create view deposits_view(client_name, bank_name, deposit_duration, date, deposit_percent) as
SELECT client.name  AS client_name,
       bank.name    AS bank_name,
       deposits.deposit_duration,
       deposits.date,
       bank.percent AS deposit_percent
FROM deposits
         JOIN clients client ON client.id = deposits.client_id
         JOIN banks bank ON bank.id = deposits.bank_id;

comment on view deposits_view is 'Представление депозитов';

alter table deposits_view
    owner to postgres;

